const card = document.getElementById('myCard');
const confettiContainer = document.getElementById('confetti-container');

// Harmonized golden-yellow confetti pallet
const colors = ['#ffcf5e', '#ffa834', '#ffeb3b', '#fff6d1', '#ffc107'];

card.addEventListener('click', () => {
  card.classList.toggle('flipped');
  
  if (card.classList.contains('flipped')) {
    createConfetti(100);
  }
});

function createConfetti(count) {
  for (let i = 0; i < count; i++) {
    const piece = document.createElement('div');
    piece.classList.add('confetti');
    
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    
    const size = Math.random() * 8 + 6 + 'px';
    piece.style.width = size;
    piece.style.height = size;
    
    piece.style.animationDuration = Math.random() * 2 + 2 + 's';
    piece.style.animationDelay = Math.random() * 0.5 + 's';
    
    confettiContainer.appendChild(piece);
    
    setTimeout(() => {
      piece.remove();
    }, 4500);
  }
}
